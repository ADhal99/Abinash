package com.tcs.jnj.SpringRestApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
